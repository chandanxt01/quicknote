// Package: com.ck.quicknote
